# Fix for read-only files (permission denied error)

``` bash
cmd
cd "C:\Users\tim.duffy\Documents\Calibre Library\"
attrib -R /d /S
```

# Make a symlink for a directory
``` bash
cmd
# mklink /D "symlink_location" "actual_folder_location"
mklink /D "C:\Users\tim.duffy\Documents\Calibre Library\Zenescope_no_sync\" "C:\Users\tim.duffy\Documents\Calibre_no_sync\Zenescope_no_sync\"
mklink /D "C:\Users\tim.duffy\Documents\Calibre Library\Adventure Time_no_sync\" "C:\Users\tim.duffy\Documents\Calibre_no_sync\Adventure Time_no_sync\"
mklink /D "C:\Users\tim.duffy\Documents\Calibre Library\Mike Mignola_no_sync\" "C:\Users\tim.duffy\Documents\Calibre_no_sync\Mike Mignola_no_sync\"
mklink /D "C:\Users\tim.duffy\Documents\Calibre Library\Murata Yusuke_no_sync\" "C:\Users\tim.duffy\Documents\Calibre_no_sync\Murata Yusuke_no_sync\"
mklink /D "C:\Users\tim.duffy\Documents\Calibre Library\Patrick McHale_no_sync\" "C:\Users\tim.duffy\Documents\Calibre_no_sync\Patrick McHale_no_sync\"
mklink /D "C:\Users\tim.duffy\Documents\Calibre Library\Junji Ito_no_sync\" "C:\Users\tim.duffy\Documents\Calibre_no_sync\Junji Ito_no_sync\"
mklink /D "C:\Users\tim.duffy\Documents\Calibre Library\Bryan Lee O'Malley_no_sync\" "C:\Users\tim.duffy\Documents\Calibre_no_sync\Bryan Lee O'Malley_no_sync\"
```

# Make a symlink for a file
``` bash
cmd
# mklink "symlink_location" "actual_file_location"
mklink "C:\Users\tim.duffy\Documents\Calibre Library\full-text-search.db" "C:\Users\tim.duffy\Documents\Calibre_fulltext_db\full-text-search.db"
```

# Remove empty folders
``` powershell
. .\rm_empty_dir.ps1
&$tailRecursion -Path "C:\Users\tim.duffy\Documents\Calibre Library\"
```