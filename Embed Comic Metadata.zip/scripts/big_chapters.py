import math


def main():
    chapter_starts = [
        ("84", 2209),
        ("85", 2228),
        ("86", 2249),
        ("87", 2285),
        ("88", 2310),
        ("89", 2334),
        ("Epilogue", 2358),
        ("Endnote", 2369),
        ("Ads Arcanum", 2370),
        ("End", 2380),
    ]

    # print(chapter_starts)

    # Get chapter lengths
    chapter_lens = []
    for i in range(len(chapter_starts) - 1):
        ch_name = chapter_starts[i][0]
        ch_start = chapter_starts[i][1]
        ch_end = chapter_starts[i + 1][1]
        chapter_lens.append((ch_name, math.ceil((ch_end - ch_start) / 1.242)))
    print(f"chapter_lens = {chapter_lens}")
    time_left = sum([ch[1] for ch in chapter_lens])
    print(f"total left = {math.floor(time_left / 60)}h {math.floor(time_left % 60)}m")

    # List largest chapters, in order
    big_boi_order = []

    ch_len_list = chapter_lens
    while len(ch_len_list) > 1:
        max_val = max(ch_len_list, key=lambda item: item[1])
        idx_max = ch_len_list.index(max_val)

        big_boi_order.append(max_val)
        ch_len_list = ch_len_list[idx_max + 1 :]

    print("---")
    print("(chapter, length)")
    print(*big_boi_order, sep="\n")


if __name__ == "__main__":
    main()
